package com.example.ladm_u3_p1_david_alejandro_hernandez_rubio

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var txtuser: EditText
    private lateinit var txtpassword: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        txtuser = findViewById(R.id.txtnom)
        txtpassword = findViewById(R.id.txtpassword)
        progressBar = findViewById(R.id.progressBar)
        auth = FirebaseAuth.getInstance()

        fun login (view: View){
            loginUser()
        }

    }
        private fun loginUser() {
            val user: String = txtuser.text.toString()
            val password: String = txtpassword.toString()

            if (!TextUtils.isEmpty(user) && !TextUtils.isEmpty(password)) {
                progressBar.visibility = View.VISIBLE
                auth.signInWithEmailAndPassword(user, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            action()
                        } else {
                            Toast.makeText(this," Error en la autenticacion", Toast.LENGTH_LONG).show()

                        }
                    }

            }
        }
    private fun action() {
        startActivity(Intent(this,MainActivity::class.java))    }


}


