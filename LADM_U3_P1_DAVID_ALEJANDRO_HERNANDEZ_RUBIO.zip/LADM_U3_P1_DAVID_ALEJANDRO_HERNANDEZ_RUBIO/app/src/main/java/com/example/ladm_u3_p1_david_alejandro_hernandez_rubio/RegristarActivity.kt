package com.example.ladm_u3_p1_david_alejandro_hernandez_rubio

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class RegristarActivity : AppCompatActivity() {

    private lateinit var txtnom: EditText
    private lateinit var txtdom: EditText
    private lateinit var txtcarre: EditText
    private lateinit var txtsuel: EditText
    private lateinit var txtanti: EditText
    private lateinit var txtingre: EditText
    private lateinit var txtcorreo: EditText
    private lateinit var txtpasword: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var dbReference: DatabaseReference
    private lateinit var database: FirebaseDatabase
    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContentView(R.layout.activity_regristar)
        txtanti = findViewById(R.id.txtanti)
        txtnom = findViewById(R.id.txtnom)
        txtdom = findViewById(R.id.txtdom)
        txtcarre = findViewById(R.id.txtcarre)
        txtsuel = findViewById(R.id.txtsuel)
        txtingre = findViewById(R.id.txtingre)
        txtcorreo = findViewById(R.id.txtcorreo)
        txtpasword = findViewById(R.id.txtpassword)

        progressBar = findViewById(R.id.progressBar)

        database = FirebaseDatabase.getInstance()
        auth = FirebaseAuth.getInstance()

        dbReference = database.reference.child("User")

    }

    fun register(view: View) {
        createNewAccount()


    }
    fun createNewAccount () {
        val nom:String=txtnom.text.toString ()
        val dom:String=txtdom.text.toString ()
        val carre:String=txtcarre.text.toString ()
        val suel:String=txtsuel.text.toString ()
        val anti:String=txtanti.text.toString ()
        val ingre:String=txtingre.text.toString ()
        val correo:String=txtcorreo.text.toString ()
        val pass:String=txtpasword.text.toString ()

        if (!TextUtils.isEmpty(nom) &&!TextUtils.isEmpty(nom) && !TextUtils.isEmpty(dom) && !TextUtils.isEmpty(carre) && !TextUtils.isEmpty(suel) &&
            !TextUtils.isEmpty(anti) && !TextUtils.isEmpty(ingre) && !TextUtils.isEmpty(correo) && !TextUtils.isEmpty(pass)) {

            progressBar.visibility=View.VISIBLE

            auth.createUserWithEmailAndPassword(correo,pass)
                .addOnCompleteListener(this){
                    task ->

                    if (task.isComplete){
                        val user:FirebaseUser?=auth.currentUser
                        verify(user)

                        val userBD = dbReference.child(user?.uid!!)

                        userBD.child("Nombre").setValue(nom)
                        userBD.child("Domicilio").setValue(dom)
                        userBD.child("Carrera").setValue(carre)
                        userBD.child("Sueldo").setValue(suel)
                        userBD.child("Antiguedad").setValue(anti)
                        userBD.child("Ingreso").setValue(ingre)
                        action()





                    }

                }
        }



    }

    private fun action() {
        startActivity(Intent(this,LoginActivity::class.java))
    }

    private fun verify (user: FirebaseUser?){
        user?.sendEmailVerification()
            ?.addOnCompleteListener(this){
                task ->

                if (task.isComplete){
                    Toast.makeText(this,"Correo Enviado",Toast.LENGTH_LONG).show()


                } else
                    Toast.makeText(this,"Error al Enviar",Toast.LENGTH_LONG).show()


            }

    }


    }

